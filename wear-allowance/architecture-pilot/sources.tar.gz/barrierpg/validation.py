"""Validation of the deployed candidate (the paper's validation section and its learning-and-validation algorithm).

Two tests, both conditional on training and network construction, both on fresh trajectories of
the fixed candidate:
  direct   the Bernoulli events {tau_i <= T}: one-sided exact binomial upper endpoint; at zero
           failures it is 1 - zeta^(1/N), never zero;
  value    a one-sided Hoeffding lower confidence bound on V_m from returns truncated after H
           actions, inserted into the value certificate.
zeta is an estimation error probability; alpha is the tolerated failure probability; they are not
interchangeable. Error probabilities are allocated across candidates, horizons and tests before
taking minima or selecting a policy (a union bound, which needs no independence).
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Optional

from .bounds import Bound, clip01
from .certificates import risk_from_value
from .paper import cite
from .spec import discounted_sum_to
from ._deprecation import RenamedKeys, module_getattr, renamed_attribute


def binomial_upper(k: int, n: int, err: float) -> float:
    """One-sided exact (Clopper-Pearson) upper endpoint at confidence 1 - err: the (1-err) quantile of
    Beta(k+1, n-k); 1 when k = n."""
    if n < 1 or int(n) != n or int(k) != k or not 0 <= k <= n:
        raise ValueError("require integer counts with 0 <= k <= n and n >= 1")
    if not 0.0 < err < 1.0:
        raise ValueError("err must lie in (0, 1)")
    if k == n:
        return 1.0
    if k == 0:
        return zero_failure_bound(n, err)
    from scipy.stats import beta as beta_dist
    return float(beta_dist.isf(err, k + 1, n - k))


def zero_failure_bound(n: int, err: float) -> float:
    """Smallest tolerance that n failure-free episodes can certify at error err: 1 - err^(1/n)."""
    if n < 1 or int(n) != n or not 0.0 < err < 1.0:
        raise ValueError("require integer n >= 1 and err in (0, 1)")
    return -math.expm1(math.log(err) / n)


def episodes_for_tolerance(alpha: float, err: float, expected_failure_rate: float = 0.0) -> int:
    """Episodes needed so that the direct test can certify alpha: with no failures,
    N >= log(err) / log(1 - alpha); with an expected failure rate p < alpha, the smallest N whose
    upper endpoint at k = round(p N) failures is at most alpha (searched numerically)."""
    if alpha <= 0:
        return 0 if alpha < 0 else int(1e18)
    if alpha == 1.0:
        return 1
    n0 = int(math.ceil(math.log(err) / math.log1p(-alpha)))
    if expected_failure_rate <= 0:
        return n0
    if expected_failure_rate >= alpha:
        raise ValueError("the expected failure rate must lie below the tolerance to be certifiable")
    n = n0
    while n < 10_000_000:
        k = int(round(expected_failure_rate * n))
        if binomial_upper(k, n, err) <= alpha:
            return n
        n = int(n * 1.15) + 1
    return n


def allocate_error(zeta: float, family: int) -> float:
    """Per-statement error for `family` simultaneous statements at overall error zeta (union bound)."""
    if family < 1 or int(family) != family or not 0.0 < zeta < 1.0:
        raise ValueError("require integer family >= 1 and zeta in (0, 1)")
    return zeta / family


@dataclass
class DirectValidation:
    failures: int
    n: int
    alpha: float
    err: float
    upper: float
    zero_failure_bound: float
    event: str = "p_T"

    floor = renamed_attribute("floor", "zero_failure_bound")

    @property
    def passed(self) -> bool:
        return self.upper <= self.alpha

    def bound(self, T: Optional[int] = None) -> Bound:
        if self.event == "q_beta":
            name, hyp = "q_beta upper bound (validated)", "N fresh independent episodes under the geometric clock (each ends with probability 1-beta per period)"
        else:
            name, hyp = ("p_T upper bound (validated)" if T is None else f"p_{T} upper bound (validated)"), "N fresh independent trajectories of the fixed candidate through action T"
        return Bound(name, self.upper, cite("validation") + ", exact binomial test",
                     [hyp,
                      f"error {self.err:.3g} allocated to this statement (family allocation)"],
                     dict(failures=self.failures, n=self.n, alpha=self.alpha, err=self.err, zero_failure_bound=self.zero_failure_bound),
                     note=("passes" if self.passed else "does not pass") + f" the tolerance {self.alpha:g}; "
                          f"smallest certifiable tolerance {self.zero_failure_bound:.3g} (zero failures certify no less). Failure to certify does not prove violation; "
                          "a passed test at one horizon does not certify a longer one")


def validate_direct(failures: int, n: int, alpha: float, zeta: float, family: int = 1) -> DirectValidation:
    err = allocate_error(zeta, family)
    return DirectValidation(int(failures), int(n), float(alpha), err, binomial_upper(failures, n, err), zero_failure_bound(n, err))


# ---------------------------------------------------------------------------------------------
# The empirical certificate
# ---------------------------------------------------------------------------------------------
def hoeffding_value_lower(mean_return_H: float, H: int, N: int, zeta: float, m: float, ubar: float, beta: float) -> float:
    """V_m >= V_hat_H - (m+ubar)(1-beta^H)/(1-beta) sqrt(log(1/zeta)/(2N)) - m beta^H/(1-beta)  (Hoeffding lower bound):
    the mean of N returns truncated after H actions, less the sampling error and the truncation error."""
    S_H = discounted_sum_to(beta, H)
    return float(mean_return_H - (m + ubar) * S_H * math.sqrt(math.log(1.0 / zeta) / (2.0 * N)) - m * beta ** H / (1.0 - beta))


def risk_from_validation_value(mean_return_H: float, H: int, N: int, zeta: float, m: float, ubar: float, beta: float, T: int) -> Bound:
    """p_T <= min{1, (ubar - (1-beta) V_lower) / ((m+ubar) beta^T)} with the Hoeffding lower bound (the empirical certificate)."""
    V_low = hoeffding_value_lower(mean_return_H, H, N, zeta, m, ubar, beta)
    b = risk_from_value(V_low, m, ubar, beta, T)
    b.source = cite("validation") + ", empirical certificate with " + cite("value_certificate")
    b.hypotheses = ["returns are the clipped rewards r_m in [-m, ubar], truncated after H actions, N fresh trajectories",
                    "ubar is a valid upper bound on the one-step utility"]
    b.inputs.update(V_lower=V_low, mean_return_H=mean_return_H, H=H, N=N, zeta=zeta)
    return b


def value_resolution_check(beta: float, H: int, T: int, N: int, zeta: float, alpha: float) -> dict:
    """Before training: the empirical certificate can certify p_T <= alpha < 1 only if
    beta^(H-T) + (1-beta^H)/beta^T sqrt(log(1/zeta)/(2N)) <= alpha  (a necessary condition).
    Increasing m cannot repair a failure of this check."""
    lhs = beta ** (H - T) + (1.0 - beta ** H) / beta ** T * math.sqrt(math.log(1.0 / zeta) / (2.0 * N))
    return RenamedKeys(renamed={"floor": "left_side", "tail_term": "truncation_error"}, attainable=lhs <= alpha, left_side=lhs, alpha=alpha,
                truncation_error=beta ** (H - T), statistical_term=(1.0 - beta ** H) / beta ** T * math.sqrt(math.log(1.0 / zeta) / (2.0 * N)))


def physical_horizon_risk(V_mH: float, H: int, m: float, ubar: float, beta: float, T: int,
                          N: Optional[int] = None, zeta: Optional[float] = None, *, u_minus: float = 0.0) -> Bound:
    """Task that ends after H actions, T < H:
    p_T <= min{1, (ubar S_H - V_m^(H)) / ((m+ubar) beta^T (1-beta^(H-T))/(1-beta))}  (physical horizon).
    With N and zeta, V_mH is the mean complete return. Use u_minus for a reward that pays
    unclipped utility before failure, with -u_minus a valid utility lower bound. Its sampling
    range is (max(m, u_minus) + ubar) S_H, while the failure charge uses m."""
    if not 0 <= T < H or m + ubar <= 0 or u_minus < 0:
        raise ValueError("require 0 <= T < H, m + ubar > 0 and u_minus >= 0")
    if (N is None) != (zeta is None):
        raise ValueError("N and zeta must be supplied together")
    S_H = discounted_sum_to(beta, H)
    V = V_mH
    if N is not None:
        V = hoeffding_lower(V_mH, N, zeta, -max(m, u_minus) * S_H, ubar * S_H)
    den = (m + ubar) * beta ** T * (1.0 - beta ** (H - T)) / (1.0 - beta)
    return Bound(f"p_{T} upper bound (physical horizon H={H})", clip01((ubar * S_H - V) / den),
                 cite("validation") + ", physical-horizon value certificate",
                 ["failure at t is charged the remaining discounted total -m(1-beta^(H-t))/(1-beta)",
                  "ubar bounds the utility; u_minus bounds the magnitude of any unclipped negative pre-failure utility"],
                 dict(V_mH=V_mH, V_used=V, H=H, m=m, ubar=ubar, beta=beta, T=T, N=N, zeta=zeta, u_minus=u_minus))


def hoeffding_lower(mean: float, N: int, zeta: float, low: float, high: float) -> float:
    """One-sided Hoeffding lower confidence bound at error zeta for the mean of N independent returns in [low, high]."""
    return float(mean - (high - low) * math.sqrt(math.log(1.0 / zeta) / (2.0 * N)))


def lump_sanction_risk(V_H: float, H: int, nu: float, ubar: float, beta: float, T: int, N: Optional[int] = None,
                       zeta: Optional[float] = None, u_minus: float = 0.0) -> Bound:
    """A task that ends after H actions with a flat penalty nu charged once at the failing action (a lump sanction, the
    fixed-multiplier form): since ubar S_H - V^(H) >= nu E[beta^tau 1{tau <= T}],
        p_T <= min{1, (ubar S_H - V^(H)) / (nu beta^T)}.
    This is the value certificate of the fixed-multiplier objective at a physical horizon, where a lump sum at
    failure prices E[beta^tau 1{tau < H}].
    With N and zeta, V_H is the mean complete return and is first lowered by the sampling error for the return's own range,
    (ubar + u_minus) S_H + nu: a penalty charged once widens the range by nu, not by a per-period price times S_H."""
    S_H = discounted_sum_to(beta, H)
    V = V_H
    if N is not None and zeta is not None:
        V = hoeffding_lower(V_H, N, zeta, -u_minus * S_H - nu, ubar * S_H)
    return Bound(f"p_{T} upper bound (lump sanction, H={H})", clip01((ubar * S_H - V) / (nu * beta ** T)),
                 cite("value_certificate") + ", fixed-multiplier form; " + cite("physical_price"),
                 ["the penalty nu is charged once, at the failing action; the reward before failure is the utility, unclipped",
                  "-u_minus <= u <= ubar"],
                 dict(V_H=V_H, V_used=V, H=H, nu=nu, ubar=ubar, beta=beta, T=T, N=N, zeta=zeta, u_minus=u_minus),
                 note="informative when nu beta^T is large against the utility at stake; direct validation is often sharper")


__all__ = ["binomial_upper", "zero_failure_bound", "episodes_for_tolerance", "allocate_error", "DirectValidation",
           "validate_direct", "hoeffding_value_lower", "risk_from_validation_value", "value_resolution_check",
           "physical_horizon_risk", "hoeffding_lower", "lump_sanction_risk"]


# names of version 0.7.1 and earlier, kept with a DeprecationWarning
__getattr__ = module_getattr(__name__, {"resolution_floor": "zero_failure_bound"}, globals())
